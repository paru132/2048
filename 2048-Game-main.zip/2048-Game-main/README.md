# 2048-Game designed using python as a group project
